---

copyright:
  years: 2017, 2018
lastupdated: "2018-12-07"

---

{:new_window: target="_blank"}
{:shortdesc: .shortdesc}
{:codeblock: .codeblock}
{:screen: .screen}
{:pre: .pre}

# Starter Plan-Netz betreiben
{: #operate-starter-plan-network}


***[Ist diese Seite hilfreich? Teilen Sie uns Ihre Meinung mit.](https://www.surveygizmo.com/s3/4501493/IBM-Blockchain-Documentation)***

Das Lernprogramm [Network Monitor verwenden](/docs/services/blockchain/v10_dashboard.html) zeigt Ihnen, wie Sie Ihr Starter Plan-Netz betreiben.
