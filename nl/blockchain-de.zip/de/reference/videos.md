---

copyright:
  years: 2018
lastupdated: "2018-08-31"

---

{:new_window: target="_blank"}
{:shortdesc: .shortdesc}
{:screen: .screen}
{:pre: .pre}
{:table: .aria-labeledby="caption"}
{:codeblock: .codeblock}
{:tip: .tip}
{:download: .download}


# {{site.data.keyword.blockchainfull_notm}} Platform - Einführungsvideos
{: #ibp-videos}


***[Ist diese Seite hilfreich? Teilen Sie uns Ihre Meinung mit.](https://www.surveygizmo.com/s3/4501493/IBM-Blockchain-Documentation)***


Die folgende Videoreihe vermittelt Informationen zu {{site.data.keyword.blockchainfull}} Platform und zum Einstieg in die Entwicklung eines Blockchain-Netzes.

**Hinweis**: Die Videoreihe ist in einer Wiedergabeliste enthalten und wird im folgenden Videobereich fortlaufend wiedergegeben. Sie können auch auf das Menüsymbol in der oberen linken Ecke des Videos klicken, um die Wiedergabeliste zu öffnen und zu einem anderen Video zu wechseln.

<iframe class="embed-responsive-item" id="youtubeplayer" title="Starter Plan-Videos" type="text/html" width="640" height="390" src="https://www.youtube.com/embed?listType=playlist&list=PL7LSy0eQMvjvBdal2mm74JlcNGMXYSGOe" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen> </iframe>
